<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Etkinlikler
            <a href="<?php echo base_url("product/new_form"); ?>" class="btn btn-outline btn-primary btn-xs pull-right"><i class="fa fa-plus"></i>Yeni Ekle</a>

        </h4>
    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget p-lg">

             <?php if(empty($items)) { ?>

                <div class="alert alert-info text-center">
                    <p>Burada herhangi bir etkinlik bulunmamaktadır.Eklemek için lütfen <a href="<?php echo base_url("product/new_form");?> ">tıklayınız.</a></p>
                </div>

            <?php } else {?>



            <table class="table table-hover table-striped">

                <thead>
                <th>Etkinlik Adı</th>
                <th>Tarihi</th>
                <th>Açıklama</th>
                <th>Hakkında</th>
                <th>Durumu</th>
                <th>İşlem</th>

                </thead>

                <tbody>

                <?php foreach ($items as $item) { ?>

                    <tr>
                        <td><?php echo $item->etkinlik_adi; ?></td>
                        <td><?php echo $item->etkinlik_tarihi; ?></td>
                        <td><?php echo $item->aciklama; ?></td>
                        <td><?php echo $item->hakkinda; ?></td>
                        <td>
                            <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                        </td>
                        <td>
                            <button data-url="<?php echo base_url("product/delete/$item->id"); ?>"
                                    class="btn btn-xs btn-danger btn-outline remove-btn">
                                <i class="fa fa-trash"></i> Sil
                            </button>

                            <a href="<?php echo base_url("product/update_form/$item->id"); ?>"
                               class="btn btn-xs btn-info btn-outline">
                                <i class="fa fa-pencil-square-o"></i>Düzenle
                            </a>
                        </td>
                    </tr>

                <?php }?>



                </tbody>

            </table>
             <?php } ?>

        </div><!-- .widget -->
    </div><!-- END column -->
</div>
