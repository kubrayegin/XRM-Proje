<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Etkinlik Ekleme
        </h4>


    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget">

            <div class="widget-body">

                <form action="<?php echo base_url("product/save")?>" method="post">

                    <div class="form-group">
                        <label>Etkinlik Ad</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="etkinlik_adi">

                        <?php if(isset($form_error)) {?>
                            <br>
                            <small class="pull-right input-fore-error"><?php echo form_error("etkinlik_adi"); ?></small
                        <?php }?>


                        <div class="form-group">
                            <br>
                            <br>
                            <label>Etkinlik Tarihi</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="etkinlik_tarihi">
                        </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Açıklama</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="aciklama">
                        </div>

                        <div class="form-group">
                            <br>
                            <label>Hakkında</label>
                            <br>
                            <textarea class="m-0" name="hakkinda" data-plugin="summernote" data-options="{height: 250}"></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary btn-md">Kaydet</button>

                        <a href="<?php echo base_url("product"); ?>" class=" btn btn-danger btn-md ">İptal</a>

                </form>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div> <!-- END column -->


</div>

