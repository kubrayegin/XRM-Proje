<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            <?php echo "<b>$item->id</b> kaydını düzenliyorsunuz.."; ?>
        </h4>


    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget">
            <div class="widget-body">
                <form action="<?php echo base_url("duyurular/update/$item->id"); ?>" method="post">



                    <div class="form-group">
                        <label>Duyuru</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="duyuru" value="<?php echo $item->duyuru; ?>">

                        <?php if(isset($form_error)) {?>
                            <br>
                            <small class="pull-right input-fore-error"><?php echo form_error("duyuru") ?></small
                        <?php }?>
                    </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Departman</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="departman" value="<?php echo $item->departman; ?>">
                        </div>

                    <div class="form-group">
                        <br>
                        <label>Açıklama</label>
                        <br>
                        <textarea class="m-0" name="aciklama" data-plugin="summernote" data-options="{height: 250}">
                            <?php echo $item->açıklama; ?>
                        </textarea>
                    </div>
                    <button type="submit" class="btn btn-primary btn-md">Kaydet</button>
                    <a href="<?php echo base_url("duyurular"); ?>" class=" btn btn-danger btn-md ">İptal</a>
                </form>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div> <!-- END column -->


</div>

