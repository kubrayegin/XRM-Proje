<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            <?php echo "<b>$item->ad</b> kaydını düzenliyorsunuz.."; ?>
        </h4>


    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget">
            <div class="widget-body">
                <form action="<?php echo base_url("personeller/update/$item->id"); ?>" method="post">

                    <div class="form-group">
                        <label>Ad</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="ad" value="<?php echo $item->ad; ?>">
                    </div>

                    <?php if(isset($form_error)) {?>
                        <br>
                        <small class="pull-right input-fore-error"><?php echo form_error("departman_no") ?></small
                    <?php }?>

                    <div class="form-group">
                        <br>
                        <label>Soyad</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="soyad" value="<?php echo $item->soyad; ?>">
                    </div>

                    <div class="form-group">
                        <br>
                        <br>
                        <label>Doğum Tarihi</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="dogum_tarihi" value="<?php echo $item->dogum_tarihi; ?>">
                    </div>

                    <div class="form-group"><br>
                        <br>
                        <label>Cinsiyet</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="cinsiyet" value="<?php echo $item->cinsiyet; ?>">
                    </div>

                    <div class="form-group">
                        <br>
                        <label>Medeni Hal</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="medeni_hal" value="<?php echo $item->medeni_hal; ?>">
                    </div>

                    <div class="form-group">
                        <br>
                        <label>Kimlik No</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="kimlik_no" value="<?php echo $item->kimlik_no; ?>">
                    </div>

                    <div class="form-group">
                        <br>
                        <label>Adres</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="adres" value="<?php echo $item->adres; ?>">
                    </div>

                    <div class="form-group">
                        <br>
                        <label>Şehir</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="sehir" value="<?php echo $item->sehir; ?>">
                    </div>

                    <div class="form-group">
                        <br>
                        <label>Telefon</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="telefon" value="<?php echo $item->telefon; ?>">
                    </div>

                    <div class="form-group">
                        <br>
                        <label>Mail</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="mail" value="<?php echo $item->mail; ?>">
                    </div>

                    <button type="submit" class="btn btn-primary btn-md">Kaydet</button>

                    <a href="<?php echo base_url("personeller"); ?>" class=" btn btn-danger btn-md ">İptal</a>

                </form>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div> <!-- END column -->


</div>

