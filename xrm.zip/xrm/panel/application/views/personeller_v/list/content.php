<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Personeller

            <a href="<?php echo base_url("personeller/new_form"); ?>" class="btn btn-outline btn-primary btn-xs pull-right"><i class="fa fa-plus"></i>Yeni Ekle</a>


        </h4>
    </div><!-- END column -->
    <div class="col-md-12" >
        <div class="widget p-lg">

            <?php if(empty($items)) { ?>

                <div class="alert alert-info text-center">
                    <p>Burada herhangi bir personel bulunmamaktadır.Eklemek için lütfen <a href="<?php echo base_url("personeller/new_form");?> ">tıklayınız.</a></p>
                </div>

            <?php } else {?>

                <table class="table table-hover table-striped">

                    <thead>
                    <th>Ad</th>
                    <th>Soyad</th>
                    <th>Doğum Tarihi</th>
                    <th>Cinsiyet</th>
                    <th>Medeni Hal</th>
                    <th>Kimlik No</th>
                    <th>Adres</th>
                    <th>Şehir</th>
                    <th>Telefon</th>
                    <th>Mail</th>
                    <th>Durum</th>
                    <th>İşlem</th>

                    </thead>

                    <tbody>


                    <?php foreach ($items as $item) { ?>

                        <tr>
                            <td><?php echo $item->ad; ?></td>
                            <td><?php echo $item->soyad; ?></td>
                            <td><?php echo $item->dogum_tarihi; ?></td>
                            <td><?php echo $item->cinsiyet; ?></td>
                            <td><?php echo $item->medeni_hal; ?></td>
                            <td><?php echo $item->kimlik_no; ?></td>
                            <td><?php echo $item->adres; ?></td>
                            <td><?php echo $item->sehir; ?></td>
                            <td><?php echo $item->telefon; ?></td>
                            <td><?php echo $item->mail; ?></td>
                            <td>
                                <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                            </td>
                            <td>
                                <button data-url="<?php echo base_url("personeller/delete/$item->id"); ?>"
                                        class="btn btn-xs btn-danger btn-outline remove-btn">
                                    <i class="fa fa-trash"></i> Sil
                                </button>

                                <a href="<?php echo base_url("personeller/update_form/$item->id"); ?>"
                                   class="btn btn-xs btn-info btn-outline">
                                    <i class="fa fa-pencil-square-o"></i>Düzenle
                                </a>
                            </td>
                        </tr>

                    <?php }?>

                    </tbody>

                </table>
            <?php } ?>
        </div><!-- .widget -->
    </div><!-- END column -->




</div>
