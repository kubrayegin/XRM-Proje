<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Personel Ekleme
        </h4>


    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget">
            <div class="widget-body">

                <form action="<?php echo base_url("personeller/save")?>" method="post">

                    <div class="form-group">
                        <label>Ad</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="ad">

                        <?php if(isset($form_error)) {?>
                            <br>
                            <small class="pull-right input-fore-error"><?php echo form_error("ad"); ?></small
                        <?php }?>


                        <div class="form-group">
                            <br>
                            <br>
                            <label>Soyad</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="soyad">
                        </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Doğum Tarihi</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="dogum_tarihi">
                        </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Cinsiyet</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="cinsiyet">
                        </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Medeni Hal</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="medeni_hal">
                        </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Uyruk</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="uyruk">
                        </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Kimlik No</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="kimlik_no">
                        </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Adres</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="adres">
                        </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Ülke</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="ulke">
                        </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Şehir</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="sehir">
                        </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Telefon</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="telefon">
                        </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Mail</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="mail">
                        </div>

                        <button type="submit" class="btn btn-primary btn-md">Kaydet</button>

                        <a href="<?php echo base_url("personeller"); ?>" class=" btn btn-danger btn-md ">İptal</a>

                </form>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div> <!-- END column -->


</div>

