<link rel="stylesheet" href="<?php echo base_url("assets");?>/assets/css/misc-pages.css">
