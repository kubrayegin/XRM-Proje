<script src="<?php echo base_url("assets"); ?>/assets/js/iziToast.min.js"></script>

<?php $this->load->view("includes/alert"); ?>
