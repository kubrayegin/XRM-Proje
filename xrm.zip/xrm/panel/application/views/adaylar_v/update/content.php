<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            <?php echo "<b>$item->ad</b> <b>$item->soyad</b> kaydını düzenliyorsunuz.."; ?>
        </h4>


    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget">
            <div class="widget-body">
                <form action="<?php echo base_url("adaylar/update/$item->id"); ?>" method="post">



                    <div class="form-group">
                        <label>Ad</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="ad" value="<?php echo $item->ad; ?>">

                        <?php if(isset($form_error)) {?>
                            <br>
                            <small class="pull-right input-fore-error"><?php echo form_error("ad") ?></small
                        <?php }?>
                    </div>

                        <div class="form-group">
                            <br>
                            <br>
                            <label>Soyad</label>
                            <input type="text" class="form-control"  placeholder="Başlık" name="soyad" value="<?php echo $item->soyad; ?>">
                        </div>

                    <div class="form-group">
                        <br>
                        <label>Telefon</label>
                        <br>
                        <textarea class="m-0" name="telefon" data-plugin="summernote" data-options="{height: 250}">
                            <?php echo $item->telefon; ?>
                        </textarea>
                    </div>

                    <div class="form-group"><br>
                        <br>
                        <label>E Mail</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="mail" value="<?php echo $item->mail; ?>">
                    </div>
                    <button type="submit" class="btn btn-primary btn-md">Kaydet</button>
                    <a href="<?php echo base_url("adaylar"); ?>" class=" btn btn-danger btn-md ">İptal</a>
                </form>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div> <!-- END column -->


</div>

