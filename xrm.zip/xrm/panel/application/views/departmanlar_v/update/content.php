<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            <?php echo "<b>$item->departman_adi</b> kaydını düzenliyorsunuz.."; ?>
        </h4>

    </div><!-- END column -->
    <div class="col-md-12">
        <div class="widget">
            <div class="widget-body">
                <form action="<?php echo base_url("departmanlar/update/$item->id"); ?>" method="post">

                    <div class="form-group">
                        <label>Departman Ad</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="departman_adi" value="<?php echo $item->departman_adi; ?>">

                        <?php if(isset($form_error)) {?>
                            <br>
                            <small class="pull-right input-fore-error"><?php echo form_error("departman_adi") ?></small
                        <?php }?>
                    </div>

                    <div class="form-group">
                        <br>
                        <label>Departman No</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="departman_no" value="<?php echo $item->departman_no; ?>">
                    </div>


                    <div class="form-group">
                        <br>
                        <br>
                        <label>Sorumlusu</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="sorumlusu" value="<?php echo $item->sorumlusu; ?>">
                    </div>

                    <div class="form-group"><br>
                        <br>
                        <label>E Mail</label>
                        <input type="text" class="form-control"  placeholder="Başlık" name="email" value="<?php echo $item->email; ?>">
                    </div>

                    <button type="submit" class="btn btn-primary btn-md">Kaydet</button>

                    <a href="<?php echo base_url("departmanlar"); ?>" class=" btn btn-danger btn-md ">İptal</a>

                </form>
            </div><!-- .widget-body -->
        </div><!-- .widget -->
    </div> <!-- END column -->


</div>

