<div class="row">
    <div class="col-sm-12">
        <h4 class="m-b-lg">
            Departmanlar
            <a href="<?php echo base_url("departmanlar/new_form"); ?>" class="btn btn-outline btn-primary btn-xs pull-right"><i class="fa fa-plus"></i>Yeni Ekle</a>


        </h4>

        <div class="col-sm-12">
            <div class="widget p-lg">

                <?php if(empty($items)) { ?>

                    <div class="alert alert-info text-center">
                        <p>Burada herhangi bir departman bulunmamaktadır.Eklemek için lütfen <a href="<?php echo base_url("departmanlar/new_form");?> ">tıklayınız.</a></p>
                    </div>




                <?php } else {?>

                    <table class="table table-hover table-striped">
                        <thead>
                        <th>Departman Adı</th>
                        <th>Departman No</th>
                        <th>Sorumlusu</th>
                        <th>E Mail</th>
                        <th>Durum</th>
                        <th>İşlem</th>
                        </thead>

                        <tbody>

                        <?php foreach ($items as $item){?>
                            <tr>
                                <td><?php echo $item->departman_adi; ?></td>
                                <td><?php echo $item->departman_no; ?></td>
                                <td><?php echo $item->sorumlusu; ?></td>
                                <td><?php echo $item->email; ?></td>
                                <td>
                                    <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                                </td>
                                <td>
                                    <button data-url="<?php echo base_url("departmanlar/delete/$item->id"); ?>"
                                            class="btn btn-xs btn-danger btn-outline remove-btn">
                                        <i class="fa fa-trash"></i> Sil
                                    </button>

                                    <a href="<?php echo base_url("departmanlar/update_form/$item->id"); ?>"
                                       class="btn btn-xs btn-info btn-outline">
                                        <i class="fa fa-pencil-square-o"></i>Düzenle
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>


                        </tbody>
                    </table>
                <?php }?>



            </div>
        </div>
    </div>