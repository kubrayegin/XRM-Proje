<div class="row">
    <div class="col-md-12">
        <h4 class="m-b-lg">
            Eğitimler
            <a href="<?php echo base_url("egitimler/new_form"); ?> " class="btn btn-outline btn-primary btn-xs pull-right"><i class="fa fa-plus"></i>Yeni Ekle</a>

        </h4>
    </div>

        <div class="col-md-12">
            <div class="widget p-lg">

                <?php if(empty($items)) { ?>

                    <div class="alert alert-info text-center">
                        <p>Burada herhangi bir eğitim bilgisi bulunmamaktadır.Eklemek için lütfen <a href="<?php echo base_url("egitimler/new_form");?> ">tıklayınız.</a></p>
                    </div>

                <?php } else {?>

                    <table class="table table-hover table-striped">

                        <thead>
                         <th>Eğitim ID</th>
                         <th>Eğitim Adı</th>
                         <th>Eğitim Konusu</th>
                         <th>Eğitim Tarihi</th>
                         <th>Durum</th>
                         <th>İşlem</th>
                        </thead>


                        <tbody>

                        <?php foreach ($items as $item) { ?>

                            <tr>
                                <td><?php echo $item->egitim_id; ?></td>
                                <td><?php echo $item->egitim_adi; ?></td>
                                <td><?php echo $item->egitim_konusu; ?></td>
                                <td><?php echo $item->egitim_tarihi; ?></td>

                                <td>
                                    <input id="switch-2-2" type="checkbox" data-switchery data-color="#10c469" checked />
                                </td>

                                <td>
                                    <button data-url="<?php echo base_url("egitimler/delete/$item->egitim_id"); ?>"
                                            class="btn btn-xs btn-danger btn-outline remove-btn">
                                        <i class="fa fa-trash"></i> Sil
                                    </button>

                                    <a href="<?php echo base_url("egitimler/update_form/$item->egitim_id"); ?>"
                                       class="btn btn-xs btn-info btn-outline">
                                        <i class="fa fa-pencil-square-o"></i>Düzenle
                                    </a>
                                </td>
                            </tr>

                        <?php }?>

                        </tbody>

                    </table>
                <?php }?>


            </div>
        </div>
    </div>