<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Personeller extends CI_Controller {

    public $viewFolder = "";

    public function __construct()
    {
        parent::__construct();

        $this->viewFolder = "personeller_v";
        $this->load->model('Personeller_model');

        if(!get_active_user()){
            redirect(base_url("login"));
        }
    }

    public function index()
    {
        $viewData = new stdClass();

        /** Tablodan Verilerin Getirilmesi.. */
        $items= $this->Personeller_model->get_all();

        /** View'e gönderilecek Değişkenlerin Set Edilmesi.. */

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "list";
        $viewData->items = $items;

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }

    public function new_form() {


        $viewData = new stdClass();

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "add";

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);

    }

    public function save() {

        $this->load->library("form_validation");

        //Kurallar yazılır
        $this->form_validation->set_rules("ad","soyad","required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "<b>Ad</b> alanı doldurulmalıdır."
            )
        );

        //Form Validation Geliştirilir..
        //TRUE=FALSE
        $validate= $this->form_validation->run();

        if($validate) {

            $insert = $this->Personeller_model->add (
                array(
                    "ad"           =>$this->input->post("ad"),
                    "soyad"        =>$this->input->post("soyad"),
                    "dogum_tarihi" =>$this->input->post("dogum_tarihi"),
                    "cinsiyet"     =>$this->input->post("cinsiyet"),
                    "medeni_hal"   =>$this->input->post("medeni_hal"),
                    "kimlik_no"    =>$this->input->post("kimlik_no"),
                    "adres"        =>$this->input->post("adres"),
                    "sehir"        =>$this->input->post("sehir"),
                    "telefon"      =>$this->input->post("telefon"),
                    "mail"         =>$this->input->post("mail")
                )
            );

            //TODO Alert sistemi eklenecek...
            if($insert) {

                redirect(base_url("personeller"));

            } else {

                redirect(base_url("personeller"));
            }

        }else {
            $viewData = new stdClass();

            $viewData->viewFolder = $this->viewFolder;
            $viewData->subViewFolder = "add";
            $viewData->form_error=true;

            $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);


        }

        //Başarılı ise
        //Kayıt işlemi başlar
        //Başarısız ise
        //Hata ekranda gösterilir.

    }

    public function update_form($id) {

        $viewData = new stdClass();

        $item = $this->Personeller_model->get(
            array(
                "id" => $id,
            )
        );

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "update";
        //$viewData->form_error=true;
        $viewData->item = $item;

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);


    }

    public function update($id) {

        $this->load->library("form_validation");

        //Kurallar yazılır
        $this->form_validation->set_rules("ad","soyad","required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "<b>Ad</b> alanı doldurulmalıdır."
            )
        );

        //Form Validation Geliştirilir..
        //TRUE=FALSE
        $validate= $this->Personeller_model->run();

        if($validate) {

            $update = $this->Personeller_model->update (
                array(
                    "id" => $id

                ),
                    array(
                        "ad"           =>$this->input->post("ad"),
                        "soyad"        =>$this->input->post("soyad"),
                        "dogum_tarihi" =>$this->input->post("dogum_tarihi"),
                        "cinsiyet"     =>$this->input->post("cinsiyet"),
                        "medeni_hal"   =>$this->input->post("medeni_hal"),
                        "kimlik_no"    =>$this->input->post("kimlik_no"),
                        "adres"        =>$this->input->post("adres"),
                        "sehir"        =>$this->input->post("sehir"),
                        "telefon"      =>$this->input->post("telefon"),
                        "mail"         =>$this->input->post("mail")
                    )
            );

            //TODO Alert sistemi eklenecek...
            if($update) {

                redirect(base_url("personeller"));

            } else {

                redirect(base_url("personeller"));
            }

        }else {

            $viewData = new stdClass();

            $item = $this->Personeller_model->get(
                array(
                    "id" => $id,
                )
            );


            $viewData->viewFolder = $this->viewFolder;
            $viewData->subViewFolder = "update";
            $viewData->form_error=true;
            $viewData->item = $item;



            $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);


        }
    }

    public function delete($id) {

        $delete = $this->Personeller_model->delete(
            array(
                "id"=> $id
            )
        );

        //TODO Alert sistemi eklenecek...
        if($delete) {
            redirect(base_url("personeller"));

        } else {
            redirect(base_url("personeller"));

        }

    }
}
