<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Departmanlar extends CI_Controller {

    public $viewFolder = "";

    public function __construct()
    {
        parent::__construct();

        $this->viewFolder = "departmanlar_v";
        $this->load->model('Departmanlar_model');

        if(!get_active_user()){
            redirect(base_url("login"));
        }
    }

    public function index()
    {
        $viewData = new stdClass();

        /** Tablodan Verilerin Getirilmesi.. */
        $items= $this->Departmanlar_model->get_all();

        /** View'e gönderilecek Değişkenlerin Set Edilmesi.. */

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "list";
        $viewData->items = $items;

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);
    }

    public function new_form() {


        $viewData = new stdClass();

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "add";

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);

    }

    public function save() {

        $this->load->library("form_validation");

        //Kurallar yazılır
        $this->form_validation->set_rules("departman_adi","departman_no","required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "<b>Departman Adı</b> alanı doldurulmalıdır."
            )
        );

        //Form Validation Geliştirilir..
        //TRUE=FALSE
        $validate= $this->form_validation->run();

        if($validate) {

            $insert = $this->Departmanlar_model->add (
                array(
                    "departman_adi"    =>$this->input->post("departman_adi"),
                    "departman_no"     =>$this->input->post("departman_no"),
                    "sorumlusu"        =>$this->input->post("sorumlusu"),
                    "email"            =>$this->input->post("email")
                )
            );

            //TODO Alert sistemi eklenecek...
            if($insert) {

                redirect(base_url("departmanlar"));

            } else {

                redirect(base_url("departmanlar"));
            }

        }else {
            $viewData = new stdClass();

            $viewData->viewFolder = $this->viewFolder;
            $viewData->subViewFolder = "add";
            $viewData->form_error=true;


            $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);


        }

        //Başarılı ise
        //Kayıt işlemi başlar
        //Başarısız ise
        //Hata ekranda gösterilir.

    }

    public function update_form($id) {

        $viewData = new stdClass();

        $item = $this->Departmanlar_model->get(
            array(
                "id" => $id,
            )
        );

        $viewData->viewFolder = $this->viewFolder;
        $viewData->subViewFolder = "update";
        $viewData->item = $item;

        $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);


    }

    public function update($id) {

        $this->load->library("form_validation");

        //Kurallar yazılır
        $this->form_validation->set_rules("departman_adi","departman_no","required|trim");

        $this->form_validation->set_message(
            array(
                "required" => "<b>Departman Adı</b> alanı doldurulmalıdır."
            )
        );

        //Form Validation Geliştirilir..
        //TRUE=FALSE
        $validate= $this->form_validation->run();

        if($validate) {

            $update = $this->Departmanlar_model->update (
                array(
                    "id" => $id
                ),
                array(
                    "departman_adi"    =>$this->input->post("departman_adi"),
                    "departman_no"  =>$this->input->post("departman_no"),
                    "sorumlusu" =>$this->input->post("sorumlusu"),
                    "email" =>$this->input->post("email")
                )
            );

            //TODO Alert sistemi eklenecek...
            if($update) {

                redirect(base_url("departmanlar"));

            } else {

                redirect(base_url("departmanlar"));
            }

        }else {

            $viewData = new stdClass();

            $item = $this->Departmanlar_model->get(
                array(
                    "id" => $id,
                )
            );


            $viewData->viewFolder = $this->viewFolder;
            $viewData->subViewFolder = "update";
            $viewData->form_error=true;
            $viewData->item = $item;



            $this->load->view("{$viewData->viewFolder}/{$viewData->subViewFolder}/index", $viewData);


        }
    }

    public function delete($id) {

        $delete = $this->Departmanlar_model->delete(
            array(
                "id"=> $id
            )
        );

        //TODO Alert sistemi eklenecek...
        if($delete) {
            redirect(base_url("departmanlar"));

        } else {
            redirect(base_url("departmanlar"));

        }

    }
}
