<?php

class Test extends CI_Controller{

    public $viewFolder = "";

    public function __construct()
    {
        parent::__construct();
        $this->viewFolder = "test_v";

        if(!get_active_user()){
            redirect(base_url("login"));
        }

    }

    public function index(){

        $viewData = new stdClass();
        $viewData->viewFolder = $this->viewFolder;
       

        $this->load->view("{$viewData->viewFolder}/index", $viewData);
    }


}
?>